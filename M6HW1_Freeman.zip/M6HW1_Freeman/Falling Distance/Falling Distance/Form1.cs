﻿/**
 * 04/25/18 
 * CSC 153
 * Michael Freeman
 * Falling Distance
 */


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Falling_Distance
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void calculateButton_Click(object sender, EventArgs e)
        {
            // starts calculate
            double time, value;
            time = double.Parse(tTextbox.Text);

            value = FallingDistance(time);
            // Displays message
            MessageBox.Show("Distance of the object: " + value + "m/sec");
        }
        
        private double FallingDistance(double time)
        {
            // Starting the return
            return 0.5 * 9.8 * (time * time);
        }
        
        private void exitButton_Click_1(object sender, EventArgs e)
        {
            // Closes program
            this.Close();
        }
    }
}