﻿namespace M1HW3_Freeman
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.headsBox = new System.Windows.Forms.PictureBox();
            this.tailsBox = new System.Windows.Forms.PictureBox();
            this.headButton = new System.Windows.Forms.Button();
            this.tailsButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.headsBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tailsBox)).BeginInit();
            this.SuspendLayout();
            // 
            // headsBox
            // 
            this.headsBox.Image = ((System.Drawing.Image)(resources.GetObject("headsBox.Image")));
            this.headsBox.Location = new System.Drawing.Point(12, 12);
            this.headsBox.Name = "headsBox";
            this.headsBox.Size = new System.Drawing.Size(239, 209);
            this.headsBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.headsBox.TabIndex = 0;
            this.headsBox.TabStop = false;
            this.headsBox.Visible = false;
            // 
            // tailsBox
            // 
            this.tailsBox.Image = ((System.Drawing.Image)(resources.GetObject("tailsBox.Image")));
            this.tailsBox.Location = new System.Drawing.Point(352, 12);
            this.tailsBox.Name = "tailsBox";
            this.tailsBox.Size = new System.Drawing.Size(239, 209);
            this.tailsBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.tailsBox.TabIndex = 1;
            this.tailsBox.TabStop = false;
            this.tailsBox.Visible = false;
            // 
            // headButton
            // 
            this.headButton.Location = new System.Drawing.Point(12, 339);
            this.headButton.Name = "headButton";
            this.headButton.Size = new System.Drawing.Size(154, 23);
            this.headButton.TabIndex = 2;
            this.headButton.Text = "Heads Button";
            this.headButton.UseVisualStyleBackColor = true;
            this.headButton.Click += new System.EventHandler(this.headButton_Click);
            // 
            // tailsButton
            // 
            this.tailsButton.Location = new System.Drawing.Point(245, 339);
            this.tailsButton.Name = "tailsButton";
            this.tailsButton.Size = new System.Drawing.Size(149, 23);
            this.tailsButton.TabIndex = 3;
            this.tailsButton.Text = "Show Tails";
            this.tailsButton.UseVisualStyleBackColor = true;
            this.tailsButton.Click += new System.EventHandler(this.tailsButton_Click_1);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(455, 339);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(136, 23);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(603, 497);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.tailsButton);
            this.Controls.Add(this.headButton);
            this.Controls.Add(this.tailsBox);
            this.Controls.Add(this.headsBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.headsBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tailsBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox headsBox;
        private System.Windows.Forms.PictureBox tailsBox;
        private System.Windows.Forms.Button headButton;
        private System.Windows.Forms.Button tailsButton;
        private System.Windows.Forms.Button exitButton;
    }
}

