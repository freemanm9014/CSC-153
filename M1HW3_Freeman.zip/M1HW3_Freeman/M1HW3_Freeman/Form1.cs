﻿/**
* 02/04/2018
* CSC 153
* Group 2
* heads or tails 
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW3_Freeman
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
                        
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void tailsButton_Click_1(object sender, EventArgs e)
        {
            tailsBox.Visible = true;
            headsBox.Visible = false;
        }

        private void headButton_Click(object sender, EventArgs e)
        {
            headsBox.Visible = true;
            tailsBox.Visible = false;
        }

        private void exitButton_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
