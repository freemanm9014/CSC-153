﻿namespace M1HW1_Freeman
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sinisterButton = new System.Windows.Forms.Button();
            this.meduimButton = new System.Windows.Forms.Button();
            this.dexterButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.translationLabel1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // sinisterButton
            // 
            this.sinisterButton.Location = new System.Drawing.Point(12, 215);
            this.sinisterButton.Name = "sinisterButton";
            this.sinisterButton.Size = new System.Drawing.Size(99, 23);
            this.sinisterButton.TabIndex = 0;
            this.sinisterButton.Text = "Sinister";
            this.sinisterButton.UseVisualStyleBackColor = true;
            this.sinisterButton.Click += new System.EventHandler(this.sinisterButton_Click_1);
            // 
            // meduimButton
            // 
            this.meduimButton.Location = new System.Drawing.Point(189, 215);
            this.meduimButton.Name = "meduimButton";
            this.meduimButton.Size = new System.Drawing.Size(93, 23);
            this.meduimButton.TabIndex = 1;
            this.meduimButton.Text = "Meduim";
            this.meduimButton.UseVisualStyleBackColor = true;
            this.meduimButton.Click += new System.EventHandler(this.meduimButton_Click_1);
            // 
            // dexterButton
            // 
            this.dexterButton.Location = new System.Drawing.Point(345, 215);
            this.dexterButton.Name = "dexterButton";
            this.dexterButton.Size = new System.Drawing.Size(101, 23);
            this.dexterButton.TabIndex = 2;
            this.dexterButton.Text = "Dexter";
            this.dexterButton.UseVisualStyleBackColor = true;
            this.dexterButton.Click += new System.EventHandler(this.dexterButton_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(177, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Latin to English";
            // 
            // translationLabel1
            // 
            this.translationLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.translationLabel1.Location = new System.Drawing.Point(130, 118);
            this.translationLabel1.Name = "translationLabel1";
            this.translationLabel1.Size = new System.Drawing.Size(210, 45);
            this.translationLabel1.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(458, 315);
            this.Controls.Add(this.translationLabel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dexterButton);
            this.Controls.Add(this.meduimButton);
            this.Controls.Add(this.sinisterButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button sinisterButton;
        private System.Windows.Forms.Button meduimButton;
        private System.Windows.Forms.Button dexterButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label translationLabel1;
    }
}

