﻿/**
* 02/04/2018
* CSC 153
* Michael Freeman
* Translation from latin to english
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW1_Freeman
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
         
                     
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void sinisterButton_Click_1(object sender, EventArgs e)
        {
            translationLabel1.Text = "Left";
        }

        private void meduimButton_Click_1(object sender, EventArgs e)
        {
            translationLabel1.Text = "Center";
        }

        private void dexterButton_Click_1(object sender, EventArgs e)
        {
            translationLabel1.Text = "Right";
        }
    }
}
