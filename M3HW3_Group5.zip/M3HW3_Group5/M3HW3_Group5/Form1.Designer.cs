﻿namespace M3HW3_Group5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.workshopListBox = new System.Windows.Forms.ListBox();
            this.displayLabel = new System.Windows.Forms.Label();
            this.workshopDisplayLabel = new System.Windows.Forms.Label();
            this.daysDisplayLabel = new System.Windows.Forms.Label();
            this.feeDisplayLabel = new System.Windows.Forms.Label();
            this.locationListBox = new System.Windows.Forms.ListBox();
            this.selectLocationDisplayLabel = new System.Windows.Forms.Label();
            this.locationDisplayLabel = new System.Windows.Forms.Label();
            this.feePerDayDisplayLabel = new System.Windows.Forms.Label();
            this.registrationDisplayLabel = new System.Windows.Forms.Label();
            this.lodgingDisplayLabel = new System.Windows.Forms.Label();
            this.totalDisplayLabel = new System.Windows.Forms.Label();
            this.registrationLabel = new System.Windows.Forms.Label();
            this.lodgingLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // workshopListBox
            // 
            this.workshopListBox.FormattingEnabled = true;
            this.workshopListBox.Items.AddRange(new object[] {
            "Handeling Stress\t\t3\t$1,000",
            "Time Management\t\t3\t$800",
            "Supervision Skills\t\t3\t$1,500",
            "Negotiation\t\t5\t$1,300",
            "How to Interview\t\t1\t$500"});
            this.workshopListBox.Location = new System.Drawing.Point(38, 79);
            this.workshopListBox.Name = "workshopListBox";
            this.workshopListBox.Size = new System.Drawing.Size(233, 69);
            this.workshopListBox.TabIndex = 0;
            // 
            // displayLabel
            // 
            this.displayLabel.AutoSize = true;
            this.displayLabel.Location = new System.Drawing.Point(35, 38);
            this.displayLabel.Name = "displayLabel";
            this.displayLabel.Size = new System.Drawing.Size(101, 13);
            this.displayLabel.TabIndex = 1;
            this.displayLabel.Text = "Select a workshop: ";
            // 
            // workshopDisplayLabel
            // 
            this.workshopDisplayLabel.AutoSize = true;
            this.workshopDisplayLabel.Location = new System.Drawing.Point(35, 63);
            this.workshopDisplayLabel.Name = "workshopDisplayLabel";
            this.workshopDisplayLabel.Size = new System.Drawing.Size(56, 13);
            this.workshopDisplayLabel.TabIndex = 2;
            this.workshopDisplayLabel.Text = "Workshop";
            // 
            // daysDisplayLabel
            // 
            this.daysDisplayLabel.AutoSize = true;
            this.daysDisplayLabel.Location = new System.Drawing.Point(171, 63);
            this.daysDisplayLabel.Name = "daysDisplayLabel";
            this.daysDisplayLabel.Size = new System.Drawing.Size(31, 13);
            this.daysDisplayLabel.TabIndex = 3;
            this.daysDisplayLabel.Text = "Days";
            // 
            // feeDisplayLabel
            // 
            this.feeDisplayLabel.AutoSize = true;
            this.feeDisplayLabel.Location = new System.Drawing.Point(237, 63);
            this.feeDisplayLabel.Name = "feeDisplayLabel";
            this.feeDisplayLabel.Size = new System.Drawing.Size(25, 13);
            this.feeDisplayLabel.TabIndex = 4;
            this.feeDisplayLabel.Text = "Fee";
            // 
            // locationListBox
            // 
            this.locationListBox.FormattingEnabled = true;
            this.locationListBox.Items.AddRange(new object[] {
            "Austin\t\t$150",
            "Chicago\t\t$225",
            "Dallas\t\t$175",
            "Orlando\t\t$300",
            "Phoenix\t\t$175",
            "Raleigh \t\t$150"});
            this.locationListBox.Location = new System.Drawing.Point(38, 222);
            this.locationListBox.Name = "locationListBox";
            this.locationListBox.Size = new System.Drawing.Size(131, 95);
            this.locationListBox.TabIndex = 5;
            // 
            // selectLocationDisplayLabel
            // 
            this.selectLocationDisplayLabel.AutoSize = true;
            this.selectLocationDisplayLabel.Location = new System.Drawing.Point(35, 175);
            this.selectLocationDisplayLabel.Name = "selectLocationDisplayLabel";
            this.selectLocationDisplayLabel.Size = new System.Drawing.Size(92, 13);
            this.selectLocationDisplayLabel.TabIndex = 6;
            this.selectLocationDisplayLabel.Text = "Select a location: ";
            // 
            // locationDisplayLabel
            // 
            this.locationDisplayLabel.AutoSize = true;
            this.locationDisplayLabel.Location = new System.Drawing.Point(35, 206);
            this.locationDisplayLabel.Name = "locationDisplayLabel";
            this.locationDisplayLabel.Size = new System.Drawing.Size(48, 13);
            this.locationDisplayLabel.TabIndex = 7;
            this.locationDisplayLabel.Text = "Location";
            // 
            // feePerDayDisplayLabel
            // 
            this.feePerDayDisplayLabel.AutoSize = true;
            this.feePerDayDisplayLabel.Location = new System.Drawing.Point(104, 206);
            this.feePerDayDisplayLabel.Name = "feePerDayDisplayLabel";
            this.feePerDayDisplayLabel.Size = new System.Drawing.Size(66, 13);
            this.feePerDayDisplayLabel.TabIndex = 8;
            this.feePerDayDisplayLabel.Text = "Fee Per Day";
            // 
            // registrationDisplayLabel
            // 
            this.registrationDisplayLabel.AutoSize = true;
            this.registrationDisplayLabel.Location = new System.Drawing.Point(347, 79);
            this.registrationDisplayLabel.Name = "registrationDisplayLabel";
            this.registrationDisplayLabel.Size = new System.Drawing.Size(69, 13);
            this.registrationDisplayLabel.TabIndex = 9;
            this.registrationDisplayLabel.Text = "Registration: ";
            // 
            // lodgingDisplayLabel
            // 
            this.lodgingDisplayLabel.AutoSize = true;
            this.lodgingDisplayLabel.Location = new System.Drawing.Point(347, 122);
            this.lodgingDisplayLabel.Name = "lodgingDisplayLabel";
            this.lodgingDisplayLabel.Size = new System.Drawing.Size(51, 13);
            this.lodgingDisplayLabel.TabIndex = 10;
            this.lodgingDisplayLabel.Text = "Lodging: ";
            // 
            // totalDisplayLabel
            // 
            this.totalDisplayLabel.AutoSize = true;
            this.totalDisplayLabel.Location = new System.Drawing.Point(347, 170);
            this.totalDisplayLabel.Name = "totalDisplayLabel";
            this.totalDisplayLabel.Size = new System.Drawing.Size(37, 13);
            this.totalDisplayLabel.TabIndex = 11;
            this.totalDisplayLabel.Text = "Total: ";
            // 
            // registrationLabel
            // 
            this.registrationLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.registrationLabel.Location = new System.Drawing.Point(434, 79);
            this.registrationLabel.Name = "registrationLabel";
            this.registrationLabel.Size = new System.Drawing.Size(133, 23);
            this.registrationLabel.TabIndex = 12;
            this.registrationLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lodgingLabel
            // 
            this.lodgingLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lodgingLabel.Location = new System.Drawing.Point(434, 121);
            this.lodgingLabel.Name = "lodgingLabel";
            this.lodgingLabel.Size = new System.Drawing.Size(133, 23);
            this.lodgingLabel.TabIndex = 13;
            this.lodgingLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalLabel
            // 
            this.totalLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalLabel.Location = new System.Drawing.Point(437, 165);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(130, 23);
            this.totalLabel.TabIndex = 14;
            this.totalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(370, 238);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 15;
            this.calculateButton.Text = "OK";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(491, 238);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 16;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 353);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.lodgingLabel);
            this.Controls.Add(this.registrationLabel);
            this.Controls.Add(this.totalDisplayLabel);
            this.Controls.Add(this.lodgingDisplayLabel);
            this.Controls.Add(this.registrationDisplayLabel);
            this.Controls.Add(this.feePerDayDisplayLabel);
            this.Controls.Add(this.locationDisplayLabel);
            this.Controls.Add(this.selectLocationDisplayLabel);
            this.Controls.Add(this.locationListBox);
            this.Controls.Add(this.feeDisplayLabel);
            this.Controls.Add(this.daysDisplayLabel);
            this.Controls.Add(this.workshopDisplayLabel);
            this.Controls.Add(this.displayLabel);
            this.Controls.Add(this.workshopListBox);
            this.Name = "Form1";
            this.Text = "Workshop Selector";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox workshopListBox;
        private System.Windows.Forms.Label displayLabel;
        private System.Windows.Forms.Label workshopDisplayLabel;
        private System.Windows.Forms.Label daysDisplayLabel;
        private System.Windows.Forms.Label feeDisplayLabel;
        private System.Windows.Forms.ListBox locationListBox;
        private System.Windows.Forms.Label selectLocationDisplayLabel;
        private System.Windows.Forms.Label locationDisplayLabel;
        private System.Windows.Forms.Label feePerDayDisplayLabel;
        private System.Windows.Forms.Label registrationDisplayLabel;
        private System.Windows.Forms.Label lodgingDisplayLabel;
        private System.Windows.Forms.Label totalDisplayLabel;
        private System.Windows.Forms.Label registrationLabel;
        private System.Windows.Forms.Label lodgingLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button exitButton;
    }
}

