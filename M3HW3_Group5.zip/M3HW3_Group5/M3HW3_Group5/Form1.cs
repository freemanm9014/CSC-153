﻿/**
* 02/28/2018
* CSC 153
* Group 5 (Gabriela Canjura, David Howland, Robert Land)
* Gabriela completed the code, Robert Completed the Flow Chart, David Completed the Pseudo Code
* Has user select a workshop and a location then calculates the lodging cost as well as the total cost
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW3_Group5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            String workshop; // hold workshop selected
            String location; // holds selected location
            int lodging; // used to calculate lodging
            int total; // has the total of lodging and the registration
            int registration = 0;// holds registration cost needs to be 
            int days = 0; // holds days of conference
         
            workshop = workshopListBox.SelectedItem.ToString(); // converts selected item to a string

            switch (workshop.Substring(0, 2)) // uses first two characters of the selected workshop to run through switch
            {
                case "Ha":
                    registration = 1000;
                    days = 3;
                    break;
                case "Ti":
                    registration = 800;
                    days = 3;
                    break;
                case "Su":
                    registration = 1500;
                    days = 3;
                    break;
                case "Ne":
                    registration = 1300;
                    days = 5;
                    break;
                case "Ho":
                    registration = 1500;
                    days = 3;
                    break;
                default:
                    MessageBox.Show("Select a Workshop.");  // displays default in message box if nothing is selected 
                    break;

            }

            location = locationListBox.SelectedItem.ToString(); //converts selected item to a string

            switch (location.Substring(0,4))// uses first four characters of the selected workshop to run through switch
            {
                case "Aust":
                    lodging = days * 150; // calculates lodging 
                    total = registration + lodging; // calculates total cost 
                    registrationLabel.Text = registration.ToString("c"); // turns int to string and then displays as currency
                    lodgingLabel.Text = lodging.ToString("C");
                    totalLabel.Text = total.ToString("c");
                    break;

                case "Chic":
                    lodging = days * 225;
                    total = registration + lodging;
                    registrationLabel.Text = registration.ToString("c");
                    lodgingLabel.Text = lodging.ToString("C");
                    totalLabel.Text = total.ToString("c");
                    break;

                case "Dall":
                    lodging = days * 175;
                    total = registration + lodging;
                    registrationLabel.Text = registration.ToString("c");
                    lodgingLabel.Text = lodging.ToString("C");
                    totalLabel.Text = total.ToString("c");
                    break;

                case "Orla":
                    lodging = days * 300;
                    total = registration + lodging;
                    registrationLabel.Text = registration.ToString("c");
                    lodgingLabel.Text = lodging.ToString("C");
                    totalLabel.Text = total.ToString("c");
                    break;

                case "Phoe":
                    lodging = days * 175;
                    total = registration + lodging;
                    registrationLabel.Text = registration.ToString("c");
                    lodgingLabel.Text = lodging.ToString("C");
                    totalLabel.Text = total.ToString("c");
                    break;

                case "Rale":
                    lodging = days * 150;
                    total = registration + lodging;
                    registrationLabel.Text = registration.ToString("c");
                    lodgingLabel.Text = lodging.ToString("C");
                    totalLabel.Text = total.ToString("c");
                    break;

                default:
                    MessageBox.Show("Select a Location."); // displays default in message box if nothing is selected 
                    break;
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
