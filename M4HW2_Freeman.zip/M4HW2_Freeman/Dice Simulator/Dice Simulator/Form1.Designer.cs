﻿namespace Dice_Simulator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.genButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.diceImageList1 = new System.Windows.Forms.ImageList(this.components);
            this.diceImageList2 = new System.Windows.Forms.ImageList(this.components);
            this.dicePictureBox2 = new System.Windows.Forms.PictureBox();
            this.dicePictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dicePictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dicePictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // genButton
            // 
            this.genButton.Location = new System.Drawing.Point(52, 393);
            this.genButton.Margin = new System.Windows.Forms.Padding(4);
            this.genButton.Name = "genButton";
            this.genButton.Size = new System.Drawing.Size(165, 86);
            this.genButton.TabIndex = 6;
            this.genButton.Text = "Generate Random Number";
            this.genButton.UseVisualStyleBackColor = true;
            this.genButton.Click += new System.EventHandler(this.genButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(549, 393);
            this.exitButton.Margin = new System.Windows.Forms.Padding(4);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(157, 86);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // diceImageList1
            // 
            this.diceImageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("diceImageList1.ImageStream")));
            this.diceImageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.diceImageList1.Images.SetKeyName(0, "1Die.bmp");
            this.diceImageList1.Images.SetKeyName(1, "2Die.bmp");
            this.diceImageList1.Images.SetKeyName(2, "3Die.bmp");
            this.diceImageList1.Images.SetKeyName(3, "4Die.bmp");
            this.diceImageList1.Images.SetKeyName(4, "5Die.bmp");
            this.diceImageList1.Images.SetKeyName(5, "6Die.bmp");
            // 
            // diceImageList2
            // 
            this.diceImageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("diceImageList2.ImageStream")));
            this.diceImageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.diceImageList2.Images.SetKeyName(0, "1Die.bmp");
            this.diceImageList2.Images.SetKeyName(1, "2Die.bmp");
            this.diceImageList2.Images.SetKeyName(2, "3Die.bmp");
            this.diceImageList2.Images.SetKeyName(3, "4Die.bmp");
            this.diceImageList2.Images.SetKeyName(4, "5Die.bmp");
            this.diceImageList2.Images.SetKeyName(5, "6Die.bmp");
            // 
            // dicePictureBox2
            // 
            this.dicePictureBox2.Location = new System.Drawing.Point(509, 97);
            this.dicePictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.dicePictureBox2.Name = "dicePictureBox2";
            this.dicePictureBox2.Size = new System.Drawing.Size(197, 175);
            this.dicePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.dicePictureBox2.TabIndex = 8;
            this.dicePictureBox2.TabStop = false;
            // 
            // dicePictureBox1
            // 
            this.dicePictureBox1.Location = new System.Drawing.Point(67, 97);
            this.dicePictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.dicePictureBox1.Name = "dicePictureBox1";
            this.dicePictureBox1.Size = new System.Drawing.Size(176, 165);
            this.dicePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.dicePictureBox1.TabIndex = 9;
            this.dicePictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(761, 725);
            this.Controls.Add(this.dicePictureBox1);
            this.Controls.Add(this.dicePictureBox2);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.genButton);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Dice Simulator";
            ((System.ComponentModel.ISupportInitialize)(this.dicePictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dicePictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button genButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ImageList diceImageList1;
        private System.Windows.Forms.ImageList diceImageList2;
        private System.Windows.Forms.PictureBox dicePictureBox2;
        private System.Windows.Forms.PictureBox dicePictureBox1;
    }
}

