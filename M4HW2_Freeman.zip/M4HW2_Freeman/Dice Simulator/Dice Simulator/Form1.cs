﻿/**
* 03/19/2018
* CSC 153
* Michael Freeman
* Random Number Dice Roll
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dice_Simulator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void genButton_Click(object sender, EventArgs e)
        {
            // Create random numbers
            Random rand1 = new Random();

            int index1 = rand1.Next(diceImageList1.Images.Count);

            dicePictureBox1.Image = diceImageList1.Images[index1];

            int index2 = rand1.Next(diceImageList2.Images.Count);

            dicePictureBox2.Image = diceImageList2.Images[index2];
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the program
            this.Close();
        }
    }
}
