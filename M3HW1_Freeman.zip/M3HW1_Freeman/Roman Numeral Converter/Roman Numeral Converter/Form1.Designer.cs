﻿namespace Roman_Numeral_Converter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calculateValueButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.romanOutputLabel = new System.Windows.Forms.Label();
            this.romanNumeralLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.integerTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // calculateValueButton
            // 
            this.calculateValueButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.calculateValueButton.Location = new System.Drawing.Point(67, 221);
            this.calculateValueButton.Name = "calculateValueButton";
            this.calculateValueButton.Size = new System.Drawing.Size(143, 23);
            this.calculateValueButton.TabIndex = 12;
            this.calculateValueButton.Text = "Calculate Value";
            this.calculateValueButton.UseVisualStyleBackColor = true;
            this.calculateValueButton.Click += new System.EventHandler(this.calculateValueButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(304, 221);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(134, 23);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // romanOutputLabel
            // 
            this.romanOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.romanOutputLabel.Location = new System.Drawing.Point(307, 124);
            this.romanOutputLabel.Name = "romanOutputLabel";
            this.romanOutputLabel.Size = new System.Drawing.Size(131, 23);
            this.romanOutputLabel.TabIndex = 10;
            // 
            // romanNumeralLabel
            // 
            this.romanNumeralLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.romanNumeralLabel.Location = new System.Drawing.Point(46, 124);
            this.romanNumeralLabel.Name = "romanNumeralLabel";
            this.romanNumeralLabel.Size = new System.Drawing.Size(242, 23);
            this.romanNumeralLabel.TabIndex = 9;
            this.romanNumeralLabel.Text = "Display Roman Numerals";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(242, 23);
            this.label1.TabIndex = 8;
            this.label1.Text = "Enter an integer between 1-10";
            // 
            // integerTextBox
            // 
            this.integerTextBox.Location = new System.Drawing.Point(307, 66);
            this.integerTextBox.Name = "integerTextBox";
            this.integerTextBox.Size = new System.Drawing.Size(131, 20);
            this.integerTextBox.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 310);
            this.Controls.Add(this.calculateValueButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.romanOutputLabel);
            this.Controls.Add(this.romanNumeralLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.integerTextBox);
            this.Name = "Form1";
            this.Text = "Roman Numeral Converter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calculateValueButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label romanOutputLabel;
        private System.Windows.Forms.Label romanNumeralLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox integerTextBox;
    }
}

