﻿/**
* 02-26-2018
* CSC 153
* Michael Freeman
* Roman Numeral Converter
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Roman_Numeral_Converter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void calculateValueButton_Click(object sender, EventArgs e)
        {
            int integer = int.Parse(integerTextBox.Text);  
            
            // Display switch statement
                  
            switch (integer)
            {
                case 1:
                    romanOutputLabel.Text = ("I");
                    break;
                case 2:
                    romanOutputLabel.Text = ("II");
                    break;
                case 3:
                    romanOutputLabel.Text = ("III");
                    break;
                case 4:
                    romanOutputLabel.Text = ("IV");
                    break;
                case 5:
                    romanOutputLabel.Text = ("V");
                    break;
                case 6:
                    romanOutputLabel.Text = ("VI");
                    break;
                case 7:
                    romanOutputLabel.Text = ("VII");
                    break;
                case 8:
                    romanOutputLabel.Text = ("VIII");
                    break;
                case 9:
                    romanOutputLabel.Text = ("IX");
                    break;
                case 10:
                    romanOutputLabel.Text = ("X");
                    break;      

                default:     // Display error message
                    romanOutputLabel.Text = ("Error: Invalid integer");
                    break;
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }
    }
}
