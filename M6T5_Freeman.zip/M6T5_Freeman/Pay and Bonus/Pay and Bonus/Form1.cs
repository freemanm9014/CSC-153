﻿/**
* 04/12/2018
* CSC 153
* MIchael Freeman
* Modularizing Input Validation with a Boolean Method 
*/




using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pay_and_Bonus
{
    public partial class Form1 : Form
    {
        // Constant field for the contribution rate
        private const decimal CONTRIB_RATE = 0.05m;

        public Form1()
        {
            InitializeComponent();
        }

        // The InputIsValid method converts the user input and stores
        // it in the arguments ( passed by refrence). If the conversion
        // is successful, the method returns true. Otherwise it returns
        // false
        private bool InputIsValid(ref decimal pay, ref decimal bonus)
        {
            // Flag variable to indicate whether the inout is good
            bool inputGood = false;

            // Try to convert both inouts to decimals.
            if (decimal.TryParse(grossPayTextBox.Text, out pay))
            {
                if (decimal.TryParse(bonusTextBox.Text, out bonus))
                {
                    // Both inputs are good
                    inputGood = true;
                }
                else
                {
                    // Display an error message for the bonus.
                    MessageBox.Show("Bouns amount is invalid");
                }
            }
            else
            {
                // Display and error message for gross pay.
                MessageBox.Show("Gross pay is invalid");
            }

            // Return the results.
            return inputGood;
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Variables for gross pay, bonus, and contributions
            decimal grosspay = 0m, bonus = 0m, contributions = 0m;

            if (InputIsValid(ref grosspay, ref bonus))
            {
                // Calculate the amount if contribution.
                contributions = (grosspay + bonus) * CONTRIB_RATE;

                //Display the contributions.
                contributionLabel.Text = contributions.ToString("c");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }
    }
}
