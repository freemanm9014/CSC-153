﻿/**
* 04/09/18 
* CSC 153
* Michael Freeman
* Get Countries 
*/




using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Using_and_Output_Parameter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        

        // The GetFileName method gets a filename from the 
        // user and assigns it to the variables passed as 
        // an argument.
        private void GetFileName(out string selectedFile)
        {
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                selectedFile = openFile.FileName;
            }
            else
            {
                selectedFile = "";
            }
        }
                
        // The GetCountries method accpets a filename as an argument.
        // It opens the specified file and dispalys
        // its contents in the countriesListBox control.
        private void GetCountries(string filename)
        {
            try
            {
                // Delcare a variable to hold a country name.
                string countryName;

                //Delcare a StreamReader variable.
                StreamReader inputFile;

                // Open the file and get Streamreader object.
                inputFile = File.OpenText(filename);

                // Clear anything curretly in the ListBox.
                countriesListBox.Items.Clear();

                //Read the files contents.
                while (!inputFile.EndOfStream)
                { 

                    // Get a country name.
                    countryName = inputFile.ReadLine();

                     // Add the country name to the ListBox.
                      countriesListBox.Items.Add(countryName);
                }
            
                     // Close the file.
                     inputFile.Close();
              }
                catch (Exception ex)
              {
                // Display an error message.
                MessageBox.Show(ex.Message);
            }
        }

        private void getCountriesButton_Click_1(object sender, EventArgs e)
        {
            {
                string filename;   // To hold the filename

                // Get the countries from the user.
                GetFileName(out filename);

                // Get the countries from the file.
                GetCountries(filename);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form.
            this.Close();
        }
    }
}
