﻿/**
 * 04/26/18
 * CSC 153
 * Michael Freeman
 * Joes Automotive
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Joe_s_Automotive
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Declare varaibels and list
            double oil = 0, lube = 0, radiator = 0, trans = 0, inspection = 0; double muffler = 0, tire = 0;
            if (oilCheckBox.Checked == true)
            {
                oil = 26;
            }
            if (lubeCheckBox.Checked == true)
            {
                lube = 18;
            }
            if (radiatorcheckbox.Checked == true)
            {
                radiator = 30;
            }
            if (transmissionCheckBox.Checked == true)
            {
                trans = 80;
            }
            if (inspectionCheckBox.Checked == true)
            {
                inspection = 15;
            }
            if (mufflerCheckBox.Checked == true)
            {
                muffler = 100;
            }
            if (tireCheckBox.Checked == true)
            {
                tire = 20;
            }
            //double variables
            double parts = double.Parse(partsTextBox.Text);
            double labor = double.Parse(laborTextBox.Text);
            double oillube = OilLubeCharges(oil, lube);
            double flush = FlushCharges(radiator, trans);
            double misc = MiscCharges(inspection, muffler, tire);
            double other = OtherCharges(parts, labor);
            double tax = TaxCharges(parts, labor, oillube, flush, misc, labor);
            double total = TotalCharges(oillube, flush, misc, other, tax);
            double services = oillube + flush + misc;
            serviceLabel.Text = services.ToString();
            partsLabel.Text = other.ToString();
            taxLabel.Text = tax.ToString();
            feesLabel.Text = total.ToString();
        }
        private double OilLubeCharges(double oil, double lube)
        {
            return oil + lube;
        }
        private double FlushCharges(double radiator, double trans)
        {
            return radiator + trans;
        }
        private double MiscCharges(double inspection, double muffler, double tire)
        {
            return inspection + muffler + tire;
        }
        private double OtherCharges(double parts, double labor)
        {
            return parts + labor;
        }
        private double TaxCharges(double parts, double labor, double oillube, double flush, double misc, double other)
        {
            if (parts != 0 && labor != 0 && (oillube != 0
                && flush != 0 && misc != 0 && other != 0))
            {
                return (0.06 * parts);
                //sales tax is 6% on parts
            }
            else
                return 0;
        }

        private double TotalCharges(double oillube, double flush, double misc, double other, double tax)
        {
            return oillube + flush + misc + other + tax;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearFees();

        }
        private void ClearOilLube()
        {
            //Clear
            if (oilCheckBox.Checked == true)
            {
                oilCheckBox.Checked = false;
            }
            if (lubeCheckBox.Checked == true)
            {
                lubeCheckBox.Checked = false;
            }
        }
        private void ClearFlushes()
        {
            //Clear
            if (radiatorcheckbox.Checked == true)
            {
                radiatorcheckbox.Checked = false;
            }
            if (transmissionCheckBox.Checked == true)
            {
                transmissionCheckBox.Checked = false;
            }
        }
        private void ClearMisc()
        {
            //Clear
            if (inspectionCheckBox.Checked == true)
            {
                inspectionCheckBox.Checked = false;
            }
            if (mufflerCheckBox.Checked == true)
            {
                mufflerCheckBox.Checked = false;
            }
            if (tireCheckBox.Checked == true)
            {
                tireCheckBox.Checked = false;
            }
        }
        private void ClearOther()
        {
            //Clear the form.
            partsTextBox.Text = null;
            laborTextBox.Text = null;
        }
        private void ClearFees()
        {
            serviceLabel.Text = null;
            partsLabel.Text = null;
            taxLabel.Text = null;
            feesLabel.Text = null;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form. 
            this.Close();
        }
    }
}
