﻿namespace M3HW3_Group6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.workshopListBox = new System.Windows.Forms.ListBox();
            this.workshopLabel = new System.Windows.Forms.Label();
            this.daysLabel = new System.Windows.Forms.Label();
            this.feeLabel = new System.Windows.Forms.Label();
            this.locationListBox = new System.Windows.Forms.ListBox();
            this.locationLabel = new System.Windows.Forms.Label();
            this.lodgingFeesLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.regTotalLabel = new System.Windows.Forms.Label();
            this.lodgeTotalLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // workshopListBox
            // 
            this.workshopListBox.FormattingEnabled = true;
            this.workshopListBox.Items.AddRange(new object[] {
            "Handling Stress\t     3\t     $1,000",
            "Time Management\t     3\t     $800",
            "Supervision Skills\t     3\t     $1,500",
            "Negotiation\t     5\t     $1,300",
            "How to Interview\t     1\t     $500"});
            this.workshopListBox.Location = new System.Drawing.Point(12, 31);
            this.workshopListBox.Name = "workshopListBox";
            this.workshopListBox.Size = new System.Drawing.Size(198, 69);
            this.workshopListBox.TabIndex = 0;
            // 
            // workshopLabel
            // 
            this.workshopLabel.AutoSize = true;
            this.workshopLabel.Location = new System.Drawing.Point(12, 12);
            this.workshopLabel.Name = "workshopLabel";
            this.workshopLabel.Size = new System.Drawing.Size(56, 13);
            this.workshopLabel.TabIndex = 1;
            this.workshopLabel.Text = "Workshop";
            // 
            // daysLabel
            // 
            this.daysLabel.AutoSize = true;
            this.daysLabel.Location = new System.Drawing.Point(74, 12);
            this.daysLabel.Name = "daysLabel";
            this.daysLabel.Size = new System.Drawing.Size(83, 13);
            this.daysLabel.TabIndex = 2;
            this.daysLabel.Text = "Number of Days";
            // 
            // feeLabel
            // 
            this.feeLabel.AutoSize = true;
            this.feeLabel.Location = new System.Drawing.Point(163, 12);
            this.feeLabel.Name = "feeLabel";
            this.feeLabel.Size = new System.Drawing.Size(84, 13);
            this.feeLabel.TabIndex = 3;
            this.feeLabel.Text = "Registration Fee";
            // 
            // locationListBox
            // 
            this.locationListBox.FormattingEnabled = true;
            this.locationListBox.Items.AddRange(new object[] {
            "Austin\t\t$150",
            "Chicago\t\t$225",
            "Dallas\t\t$175",
            "Orlando\t\t$300",
            "Phoenix\t\t$175",
            "Raleigh\t\t$150"});
            this.locationListBox.Location = new System.Drawing.Point(12, 154);
            this.locationListBox.Name = "locationListBox";
            this.locationListBox.Size = new System.Drawing.Size(128, 82);
            this.locationListBox.TabIndex = 4;
            // 
            // locationLabel
            // 
            this.locationLabel.AutoSize = true;
            this.locationLabel.Location = new System.Drawing.Point(12, 135);
            this.locationLabel.Name = "locationLabel";
            this.locationLabel.Size = new System.Drawing.Size(48, 13);
            this.locationLabel.TabIndex = 5;
            this.locationLabel.Text = "Location";
            // 
            // lodgingFeesLabel
            // 
            this.lodgingFeesLabel.AutoSize = true;
            this.lodgingFeesLabel.Location = new System.Drawing.Point(74, 135);
            this.lodgingFeesLabel.Name = "lodgingFeesLabel";
            this.lodgingFeesLabel.Size = new System.Drawing.Size(106, 13);
            this.lodgingFeesLabel.TabIndex = 6;
            this.lodgingFeesLabel.Text = "Lodging Fee per Day";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(305, 31);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(88, 31);
            this.calculateButton.TabIndex = 7;
            this.calculateButton.Text = "Calculate Costs";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // regTotalLabel
            // 
            this.regTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.regTotalLabel.Location = new System.Drawing.Point(287, 101);
            this.regTotalLabel.Name = "regTotalLabel";
            this.regTotalLabel.Size = new System.Drawing.Size(173, 23);
            this.regTotalLabel.TabIndex = 8;
            this.regTotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lodgeTotalLabel
            // 
            this.lodgeTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lodgeTotalLabel.Location = new System.Drawing.Point(287, 154);
            this.lodgeTotalLabel.Name = "lodgeTotalLabel";
            this.lodgeTotalLabel.Size = new System.Drawing.Size(173, 23);
            this.lodgeTotalLabel.TabIndex = 9;
            this.lodgeTotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalLabel
            // 
            this.totalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalLabel.Location = new System.Drawing.Point(287, 213);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(173, 23);
            this.totalLabel.TabIndex = 10;
            this.totalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(215, 106);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Registration:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(233, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Lodging:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(247, 213);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Total:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 251);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.lodgeTotalLabel);
            this.Controls.Add(this.regTotalLabel);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.lodgingFeesLabel);
            this.Controls.Add(this.locationLabel);
            this.Controls.Add(this.locationListBox);
            this.Controls.Add(this.feeLabel);
            this.Controls.Add(this.daysLabel);
            this.Controls.Add(this.workshopLabel);
            this.Controls.Add(this.workshopListBox);
            this.Name = "Form1";
            this.Text = "Workshop Selector";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox workshopListBox;
        private System.Windows.Forms.Label workshopLabel;
        private System.Windows.Forms.Label daysLabel;
        private System.Windows.Forms.Label feeLabel;
        private System.Windows.Forms.ListBox locationListBox;
        private System.Windows.Forms.Label locationLabel;
        private System.Windows.Forms.Label lodgingFeesLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label regTotalLabel;
        private System.Windows.Forms.Label lodgeTotalLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

