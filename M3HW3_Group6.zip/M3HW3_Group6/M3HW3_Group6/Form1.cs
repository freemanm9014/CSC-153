﻿/**
* 2/5/18
* CSC 153
* Justin Weihl, Michael Freeman
* Workshop and location selctor that uses switch methods to find total costs
* for registration, lodging fee and total costs.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW3_Group6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void calculateButton_Click(object sender, EventArgs e)
        {
            int shop;               //hold workshop
            int location;           //hold location
            int days = 0;            //holds days for workshop
            int regFee = 0;          //holds workshop registration fee
            int logFee = 0;
            int total;
            //holds lodging fee per day

            if (workshopListBox.SelectedIndex != -1)
            {
                //get selected input from user
                shop = workshopListBox.SelectedIndex;
                //determine registration fee
                switch (shop)
                {
                    case 0: days = 3; regFee = 1000; break;
                    case 1: days = 3; regFee = 800; break;
                    case 2: days = 3; regFee = 1500; break;
                    case 3: days = 5; regFee = 1300; break;
                    case 4: days = 1; regFee = 500; break;
                }
            }
            if (locationListBox.SelectedIndex != -1)
            {
                //get user location input
                location = locationListBox.SelectedIndex;
                //determin location fee
                switch (location)
                {
                    case 0: logFee = 150; break;
                    case 1: logFee = 225; break;
                    case 2: logFee = 175; break;
                    case 3: logFee = 300; break;
                    case 4: logFee = 175; break;
                    case 5: logFee = 150; break;

                }
            }
            //calculate and display totals
            regTotalLabel.Text = regFee.ToString("c");
            lodgeTotalLabel.Text = (""+logFee+" X "+days+" days = $" +logFee*days+"");
            total = (regFee+(logFee*days));
            totalLabel.Text = total.ToString("c");
        }
    }
}