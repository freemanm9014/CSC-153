﻿/**
* 02/04/2018
* CSC 153
* Michael Freeman
* Card Indentifer
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW2_Freeman
{
    public partial class Form1 : Form
    {
        private string ansLabel1;

        public Form1()
        {
            InitializeComponent();
        }

        private void eightofSpades_Click(object sender, EventArgs e)
        {
            ansLabel1 = "eightOfSpades";
        }

        private void twoOfDiamonds_Click(object sender, EventArgs e)
        {
            ansLabel1 = "twoOfDiamonds";
        }
        private void kingOfHearts_Click(object sender, EventArgs e)
        {
            ansLabel1 = "kingOfHearts";

        }

        private void aceOfClubs_Click(object sender, EventArgs e)
        {
            ansLabel1 = "aceOfClubs";
        }

        private void joker_Click(object sender, EventArgs e)
        {
            ansLabel1 = "joker";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}