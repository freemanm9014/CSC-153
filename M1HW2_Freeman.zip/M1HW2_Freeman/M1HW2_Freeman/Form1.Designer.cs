﻿namespace M1HW2_Freeman
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.eightOfSpades = new System.Windows.Forms.PictureBox();
            this.twoOfDiamonds = new System.Windows.Forms.PictureBox();
            this.kingOfHearts = new System.Windows.Forms.PictureBox();
            this.aceOfClubs = new System.Windows.Forms.PictureBox();
            this.Joker = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.eightOfSpades)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.twoOfDiamonds)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingOfHearts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceOfClubs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Joker)).BeginInit();
            this.SuspendLayout();
            // 
            // eightOfSpades
            // 
            this.eightOfSpades.Image = ((System.Drawing.Image)(resources.GetObject("eightOfSpades.Image")));
            this.eightOfSpades.Location = new System.Drawing.Point(12, 88);
            this.eightOfSpades.Name = "eightOfSpades";
            this.eightOfSpades.Size = new System.Drawing.Size(144, 204);
            this.eightOfSpades.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.eightOfSpades.TabIndex = 0;
            this.eightOfSpades.TabStop = false;
            // 
            // twoOfDiamonds
            // 
            this.twoOfDiamonds.Image = ((System.Drawing.Image)(resources.GetObject("twoOfDiamonds.Image")));
            this.twoOfDiamonds.Location = new System.Drawing.Point(258, 92);
            this.twoOfDiamonds.Name = "twoOfDiamonds";
            this.twoOfDiamonds.Size = new System.Drawing.Size(129, 200);
            this.twoOfDiamonds.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.twoOfDiamonds.TabIndex = 1;
            this.twoOfDiamonds.TabStop = false;
            // 
            // kingOfHearts
            // 
            this.kingOfHearts.Image = ((System.Drawing.Image)(resources.GetObject("kingOfHearts.Image")));
            this.kingOfHearts.Location = new System.Drawing.Point(492, 84);
            this.kingOfHearts.Name = "kingOfHearts";
            this.kingOfHearts.Size = new System.Drawing.Size(155, 204);
            this.kingOfHearts.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.kingOfHearts.TabIndex = 2;
            this.kingOfHearts.TabStop = false;
            // 
            // aceOfClubs
            // 
            this.aceOfClubs.Image = ((System.Drawing.Image)(resources.GetObject("aceOfClubs.Image")));
            this.aceOfClubs.Location = new System.Drawing.Point(768, 88);
            this.aceOfClubs.Name = "aceOfClubs";
            this.aceOfClubs.Size = new System.Drawing.Size(131, 200);
            this.aceOfClubs.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.aceOfClubs.TabIndex = 3;
            this.aceOfClubs.TabStop = false;
            // 
            // Joker
            // 
            this.Joker.Image = ((System.Drawing.Image)(resources.GetObject("Joker.Image")));
            this.Joker.Location = new System.Drawing.Point(981, 88);
            this.Joker.Name = "Joker";
            this.Joker.Size = new System.Drawing.Size(147, 204);
            this.Joker.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Joker.TabIndex = 4;
            this.Joker.TabStop = false;
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.CausesValidation = false;
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(419, 369);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(302, 27);
            this.label1.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(519, 424);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1128, 508);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Joker);
            this.Controls.Add(this.aceOfClubs);
            this.Controls.Add(this.kingOfHearts);
            this.Controls.Add(this.twoOfDiamonds);
            this.Controls.Add(this.eightOfSpades);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.eightOfSpades)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.twoOfDiamonds)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingOfHearts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceOfClubs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Joker)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox eightOfSpades;
        private System.Windows.Forms.PictureBox twoOfDiamonds;
        private System.Windows.Forms.PictureBox kingOfHearts;
        private System.Windows.Forms.PictureBox aceOfClubs;
        private System.Windows.Forms.PictureBox Joker;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}

