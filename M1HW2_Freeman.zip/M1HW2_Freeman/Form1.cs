﻿/**
* 02/04/2018
* CSC 153
* Michael Freeman
* Card Indentifer
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW2_Freeman
{
    public partial class Form1 : Form
    {
       

        public Form1()
        {
            InitializeComponent();
        }
                 
        
                
        private void eightOfSpades_Click_1(object sender, EventArgs e)
        {
            ansLabel1.Text = "Eight of Spades";
        }

        private void twoOfDiamonds_Click(object sender, EventArgs e)
        {
            ansLabel1.Text = "Two of Diamonds";
        }

        private void kingOfHearts_Click(object sender, EventArgs e)
        {
            ansLabel1.Text = "King of Hearts";
        }

        private void aceOfClubs_Click(object sender, EventArgs e)
        {
            ansLabel1.Text = "Ace of Clubs";
        }

        private void Joker_Click(object sender, EventArgs e)
        {
            ansLabel1.Text = "Joker";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void ansLabel1_Click(object sender, EventArgs e)
        {

        }
    }
}