﻿/**
 * 3/30/2018
 * CSC 153
 * Alex Lopez, Michael Freeman and Robert Land
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace RandomNumberFileWriter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void creatFileButton_Click(object sender, EventArgs e)
        {
            int numAmount;
            int numValue;

            if (int.TryParse(amountTextBox.Text, out numAmount))
            {
                if (saveFile.ShowDialog() == DialogResult.OK)
                {
                    StreamWriter outputFile = File.CreateText(saveFile.FileName);

                    Random rand = new Random();

                    for (int i = 1; i <= numAmount; i++)
                    {
                        numValue = rand.Next(100) + 1;

                        outputFile.WriteLine(numValue);
                    }

                    outputFile.Close();
                }
            }
            else
            {
                MessageBox.Show("Invalid input for number");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
    


