﻿/**
 * 3/30/2018
 * CSC 153
 * Alex Lopez, Michael Freeman and Robert Land
 * 
 * This application opens a file,
 * reads the content, and displas
 * the sum of numbers
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;



namespace Random_Number_File_Reader
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void openButton_Click(object sender, EventArgs e)
        {
            //initiate try clause
            try
            {
                // create variables hold output
                int numInFile;
                int numCount = 0;
                int total = 0;
                
                // check if user opens a file
                if (openFile.ShowDialog() == DialogResult.OK)
                {
                    // create StreamReader object and set pathname
                    StreamReader inputFile = File.OpenText(openFile.FileName);

                    // read file and convert content to integers
                    while (!inputFile.EndOfStream)
                    {
                        // convert to integer
                        numInFile = int.Parse(inputFile.ReadLine());

                        // accumulate numbers in file
                        numCount++;

                        // get the sum of numbers
                        total += numInFile;

                        // display the numbers in listBox
                        listBox.Items.Add(numInFile);

                        // display sum to Label
                        sumOutput.Text = total.ToString();

                        // display amount of numbers to Label
                        numbersOutput.Text = numCount.ToString();
                    }
                    //close the file
                    inputFile.Close();
                }
                // show that the user cancelled opening a file
                else
                {
                    MessageBox.Show("cancelled");
                }
            }
            // show exception error message
            catch (Exception x)
            {
                MessageBox.Show(x.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // clear all text
            listBox.Items.Clear();
            numbersOutput.Text = "";
            sumOutput.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the application
            this.Close();
        }
    }
}
