﻿namespace Random_Number_File_Reader
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openButton = new System.Windows.Forms.Button();
            this.listBox = new System.Windows.Forms.ListBox();
            this.openFile = new System.Windows.Forms.OpenFileDialog();
            this.numbersLabel = new System.Windows.Forms.Label();
            this.sumLabel = new System.Windows.Forms.Label();
            this.numbersOutput = new System.Windows.Forms.Label();
            this.sumOutput = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // openButton
            // 
            this.openButton.Location = new System.Drawing.Point(12, 206);
            this.openButton.Name = "openButton";
            this.openButton.Size = new System.Drawing.Size(105, 41);
            this.openButton.TabIndex = 0;
            this.openButton.Text = "Open and Read";
            this.openButton.UseVisualStyleBackColor = true;
            this.openButton.Click += new System.EventHandler(this.openButton_Click);
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.Location = new System.Drawing.Point(12, 12);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(172, 160);
            this.listBox.TabIndex = 1;
            // 
            // openFile
            // 
            this.openFile.FileName = "openFileDialog1";
            // 
            // numbersLabel
            // 
            this.numbersLabel.AutoSize = true;
            this.numbersLabel.Location = new System.Drawing.Point(207, 65);
            this.numbersLabel.Name = "numbersLabel";
            this.numbersLabel.Size = new System.Drawing.Size(83, 13);
            this.numbersLabel.TabIndex = 2;
            this.numbersLabel.Text = "Numbers In File:";
            // 
            // sumLabel
            // 
            this.sumLabel.AutoSize = true;
            this.sumLabel.Location = new System.Drawing.Point(207, 110);
            this.sumLabel.Name = "sumLabel";
            this.sumLabel.Size = new System.Drawing.Size(88, 13);
            this.sumLabel.TabIndex = 3;
            this.sumLabel.Text = "Sum of Numbers:";
            // 
            // numbersOutput
            // 
            this.numbersOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numbersOutput.Location = new System.Drawing.Point(318, 60);
            this.numbersOutput.Name = "numbersOutput";
            this.numbersOutput.Size = new System.Drawing.Size(37, 23);
            this.numbersOutput.TabIndex = 4;
            this.numbersOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sumOutput
            // 
            this.sumOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sumOutput.Location = new System.Drawing.Point(318, 109);
            this.sumOutput.Name = "sumOutput";
            this.sumOutput.Size = new System.Drawing.Size(37, 23);
            this.sumOutput.TabIndex = 5;
            this.sumOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(158, 206);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 41);
            this.clearButton.TabIndex = 6;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(280, 206);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 41);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(383, 280);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.sumOutput);
            this.Controls.Add(this.numbersOutput);
            this.Controls.Add(this.sumLabel);
            this.Controls.Add(this.numbersLabel);
            this.Controls.Add(this.listBox);
            this.Controls.Add(this.openButton);
            this.Name = "Form1";
            this.Text = "f";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button openButton;
        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.OpenFileDialog openFile;
        private System.Windows.Forms.Label numbersLabel;
        private System.Windows.Forms.Label sumLabel;
        private System.Windows.Forms.Label numbersOutput;
        private System.Windows.Forms.Label sumOutput;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

