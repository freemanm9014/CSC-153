﻿namespace Name_Formatter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstnameLabel = new System.Windows.Forms.Label();
            this.middlenameLabel = new System.Windows.Forms.Label();
            this.lastnameLabel = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.outputLabel = new System.Windows.Forms.Label();
            this.l_m_f_Button = new System.Windows.Forms.Button();
            this.l_f_Button = new System.Windows.Forms.Button();
            this.l_f_m_t_Button = new System.Windows.Forms.Button();
            this.t_f_m_l_Button = new System.Windows.Forms.Button();
            this.f_l_Button = new System.Windows.Forms.Button();
            this.f_m_l_Button = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.firstnameTextBox = new System.Windows.Forms.TextBox();
            this.middlenameTextBox = new System.Windows.Forms.TextBox();
            this.lastnameTextBox = new System.Windows.Forms.TextBox();
            this.titleTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // firstnameLabel
            // 
            this.firstnameLabel.AutoSize = true;
            this.firstnameLabel.Location = new System.Drawing.Point(36, 72);
            this.firstnameLabel.Name = "firstnameLabel";
            this.firstnameLabel.Size = new System.Drawing.Size(80, 17);
            this.firstnameLabel.TabIndex = 0;
            this.firstnameLabel.Text = "First Name:";
            // 
            // middlenameLabel
            // 
            this.middlenameLabel.AutoSize = true;
            this.middlenameLabel.Location = new System.Drawing.Point(36, 142);
            this.middlenameLabel.Name = "middlenameLabel";
            this.middlenameLabel.Size = new System.Drawing.Size(94, 17);
            this.middlenameLabel.TabIndex = 1;
            this.middlenameLabel.Text = "Middle Name:";
            // 
            // lastnameLabel
            // 
            this.lastnameLabel.AutoSize = true;
            this.lastnameLabel.Location = new System.Drawing.Point(36, 209);
            this.lastnameLabel.Name = "lastnameLabel";
            this.lastnameLabel.Size = new System.Drawing.Size(80, 17);
            this.lastnameLabel.TabIndex = 2;
            this.lastnameLabel.Text = "Last Name:";
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(36, 281);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(39, 17);
            this.titleLabel.TabIndex = 3;
            this.titleLabel.Text = "Title:";
            // 
            // outputLabel
            // 
            this.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabel.Location = new System.Drawing.Point(135, 376);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(456, 42);
            this.outputLabel.TabIndex = 4;
            // 
            // l_m_f_Button
            // 
            this.l_m_f_Button.Location = new System.Drawing.Point(631, 495);
            this.l_m_f_Button.Name = "l_m_f_Button";
            this.l_m_f_Button.Size = new System.Drawing.Size(75, 23);
            this.l_m_f_Button.TabIndex = 5;
            this.l_m_f_Button.Text = "L_M_F";
            this.l_m_f_Button.UseVisualStyleBackColor = true;
            this.l_m_f_Button.Click += new System.EventHandler(this.l_m_f_Button_Click);
            // 
            // l_f_Button
            // 
            this.l_f_Button.Location = new System.Drawing.Point(516, 495);
            this.l_f_Button.Name = "l_f_Button";
            this.l_f_Button.Size = new System.Drawing.Size(75, 23);
            this.l_f_Button.TabIndex = 6;
            this.l_f_Button.Text = "L_F";
            this.l_f_Button.UseVisualStyleBackColor = true;
            this.l_f_Button.Click += new System.EventHandler(this.l_f_Button_Click);
            // 
            // l_f_m_t_Button
            // 
            this.l_f_m_t_Button.Location = new System.Drawing.Point(389, 495);
            this.l_f_m_t_Button.Name = "l_f_m_t_Button";
            this.l_f_m_t_Button.Size = new System.Drawing.Size(83, 23);
            this.l_f_m_t_Button.TabIndex = 7;
            this.l_f_m_t_Button.Text = "L_F_M_T";
            this.l_f_m_t_Button.UseVisualStyleBackColor = true;
            this.l_f_m_t_Button.Click += new System.EventHandler(this.l_f_m_t_Button_Click);
            // 
            // t_f_m_l_Button
            // 
            this.t_f_m_l_Button.Location = new System.Drawing.Point(260, 495);
            this.t_f_m_l_Button.Name = "t_f_m_l_Button";
            this.t_f_m_l_Button.Size = new System.Drawing.Size(85, 23);
            this.t_f_m_l_Button.TabIndex = 8;
            this.t_f_m_l_Button.Text = "T_F_M_L";
            this.t_f_m_l_Button.UseVisualStyleBackColor = true;
            this.t_f_m_l_Button.Click += new System.EventHandler(this.t_f_m_l_Button_Click);
            // 
            // f_l_Button
            // 
            this.f_l_Button.Location = new System.Drawing.Point(135, 495);
            this.f_l_Button.Name = "f_l_Button";
            this.f_l_Button.Size = new System.Drawing.Size(83, 23);
            this.f_l_Button.TabIndex = 9;
            this.f_l_Button.Text = "F_L";
            this.f_l_Button.UseVisualStyleBackColor = true;
            this.f_l_Button.Click += new System.EventHandler(this.f_l_Button_Click);
            // 
            // f_m_l_Button
            // 
            this.f_m_l_Button.Location = new System.Drawing.Point(12, 495);
            this.f_m_l_Button.Name = "f_m_l_Button";
            this.f_m_l_Button.Size = new System.Drawing.Size(81, 23);
            this.f_m_l_Button.TabIndex = 10;
            this.f_m_l_Button.Text = "F_M_L";
            this.f_m_l_Button.UseVisualStyleBackColor = true;
            this.f_m_l_Button.Click += new System.EventHandler(this.f_m_l_Button_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(631, 346);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 11;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(631, 412);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 12;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // firstnameTextBox
            // 
            this.firstnameTextBox.Location = new System.Drawing.Point(303, 72);
            this.firstnameTextBox.Name = "firstnameTextBox";
            this.firstnameTextBox.Size = new System.Drawing.Size(246, 22);
            this.firstnameTextBox.TabIndex = 13;
            // 
            // middlenameTextBox
            // 
            this.middlenameTextBox.Location = new System.Drawing.Point(303, 142);
            this.middlenameTextBox.Name = "middlenameTextBox";
            this.middlenameTextBox.Size = new System.Drawing.Size(246, 22);
            this.middlenameTextBox.TabIndex = 14;
            // 
            // lastnameTextBox
            // 
            this.lastnameTextBox.Location = new System.Drawing.Point(303, 209);
            this.lastnameTextBox.Name = "lastnameTextBox";
            this.lastnameTextBox.Size = new System.Drawing.Size(246, 22);
            this.lastnameTextBox.TabIndex = 15;
            // 
            // titleTextBox
            // 
            this.titleTextBox.Location = new System.Drawing.Point(303, 281);
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.Size = new System.Drawing.Size(246, 22);
            this.titleTextBox.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(739, 573);
            this.Controls.Add(this.titleTextBox);
            this.Controls.Add(this.lastnameTextBox);
            this.Controls.Add(this.middlenameTextBox);
            this.Controls.Add(this.firstnameTextBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.f_m_l_Button);
            this.Controls.Add(this.f_l_Button);
            this.Controls.Add(this.t_f_m_l_Button);
            this.Controls.Add(this.l_f_m_t_Button);
            this.Controls.Add(this.l_f_Button);
            this.Controls.Add(this.l_m_f_Button);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.lastnameLabel);
            this.Controls.Add(this.middlenameLabel);
            this.Controls.Add(this.firstnameLabel);
            this.Name = "Form1";
            this.Text = "Name Formater";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label firstnameLabel;
        private System.Windows.Forms.Label middlenameLabel;
        private System.Windows.Forms.Label lastnameLabel;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.Button l_m_f_Button;
        private System.Windows.Forms.Button l_f_Button;
        private System.Windows.Forms.Button l_f_m_t_Button;
        private System.Windows.Forms.Button t_f_m_l_Button;
        private System.Windows.Forms.Button f_l_Button;
        private System.Windows.Forms.Button f_m_l_Button;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox firstnameTextBox;
        private System.Windows.Forms.TextBox middlenameTextBox;
        private System.Windows.Forms.TextBox lastnameTextBox;
        private System.Windows.Forms.TextBox titleTextBox;
    }
}

