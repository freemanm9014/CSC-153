﻿/**
* 02/25/2018
* CSC 153
* Michael Freeman
* NAME FORMATTER
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Name_Formatter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void f_m_l_Button_Click(object sender, EventArgs e)
        {

            // Declare a string variable.
            string output;

            // Concatenate the input and build the output string.
            output = firstnameTextBox.Text + " " + middlenameTextBox.Text + " " + lastnameTextBox.Text;

            // Display the output string in the Label control.
            outputLabel.Text = output;
        }

        private void l_f_m_t_Button_Click(object sender, EventArgs e)
        {
            
            string output;

            
            output = lastnameTextBox.Text + " " + firstnameTextBox.Text + " " + middlenameTextBox.Text + " " + titleTextBox.Text;

          
            outputLabel.Text = output;
        }

        private void l_m_f_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string output;

            // Concatenate the input and build the output string.
            output = lastnameTextBox.Text + " " + middlenameTextBox.Text + " " + firstnameTextBox.Text;

            // Display the output string in the Label control.
            outputLabel.Text = output;
        }

        private void f_l_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string output;

            output = firstnameTextBox.Text + " " + lastnameTextBox.Text;

            // Display the output string in the Label control.
            outputLabel.Text = output;
        }

        private void l_f_Button_Click(object sender, EventArgs e)
        {
            
            string output;

            // Concatenate the input and build the output string.
            output = lastnameTextBox.Text + " " + firstnameTextBox.Text;

            
            outputLabel.Text = output;
        }

        private void t_f_m_l_Button_Click(object sender, EventArgs e)
        {
            
            string output;

            
            output = titleTextBox.Text + " " + firstnameTextBox.Text + " " + middlenameTextBox.Text + " " + lastnameTextBox.Text;

            outputLabel.Text = output;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear the outputLabel control.
            outputLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form.
            this.Close();
        }
    }
}

