﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car
{
    class Car
    {
        private string Make;
        private int Year;
        private int Speed;

        
        public Car()
        {
            Make = "";
            Year = 0;
            Speed = 0;
        }
        
        public Car(int Year, string Make)
        {
            this.Make = Make;
            this.Year = Year;
            Speed = 0;
        }

        
        public void Accelerate()
        {
            this.Speed += 5;
        }

        
        public void Brake()
        {
            this.Speed -= 5;
        }

        public int getSpeed()
        {
            return Speed;
        }
    }
}
