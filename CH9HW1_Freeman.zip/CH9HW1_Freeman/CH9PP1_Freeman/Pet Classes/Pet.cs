﻿namespace Pet_Classes
{
    internal class Pet
    {
    }
}